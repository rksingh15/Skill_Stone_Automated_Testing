package BikeWale;

import java.awt.event.ActionEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class BikeWalaClass {

	WebDriver driver = new FirefoxDriver();

	void openPage() {
		driver.get("https://www.bikewale.com/");
		
		
		System.out.println("Testcase 0 Done !!!");
	}

	public void checkUrl() {

		String Url = "https://www.bikewale.com/";

		String checkurl = driver.getCurrentUrl();

		if (Url.equalsIgnoreCase(checkurl)) {

			System.out.println("Website link match");

			String title = driver.getTitle();
			System.out.println("Title of Page is = > " + title);

		} else
			System.out.println("Website link not match");
		
		
		System.out.println("Testcase 1 Done !!!");

	}

	void selectCity() throws InterruptedException {

		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[1]/header[1]/div[1]/div[2]/div[2]/div[1]/*[name()='svg'][1]"))
				.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[7]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]"))
				.sendKeys("Jalan");
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[7]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/span[1]/span[1]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[7]/div[2]/div[1]/span[1]")).click();
		
		System.out.println("Testcase 2 Done !!!");
	}

	void Tvs() throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,5000)");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,800)");

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[2]/div[2]/div[2]/section[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[4]/a[1]/div[1]/div[1]/img[1]"))
				.click();
		
		System.out.println("Testcase 3 Done !!!");
	}

	void topComparisons() {

		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/section[1]/div[1]/div[2]/ul[1]/li[2]/div[1]/span[1]/div[1]"))
				.click();
		
		System.out.println("Testcase 4 Done !!!");

	}

	void review() {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,800)");
		
		System.out.println("Testcase 5 Done !!!");

	}

	void clickHome() throws InterruptedException {

		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/header[1]/div[1]/div[1]/div[1]/span[1]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/nav[1]/ul[1]/li[1]/div[1]/div[1]/a[1]/span[1]"))
				.click();
		
		System.out.println("Testcase 6 Done !!!");
	}

	void newLaunch() throws InterruptedException {
		driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/header[1]/div[1]/div[1]/div[1]/span[1]"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/div[1]/div[1]/div[1]"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/div[2]/div[1]/ul[1]/li[7]/a[1]/span[1]"))
				.click();
		
		System.out.println("Testcase 7 Done !!!");


	}

	void BodyStyle() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,1200)");
		Actions aa=new Actions(driver);
		WebElement  kk=driver.findElement(By.xpath("//*[@data-testing-id='bodyStyle-tab']"));
			aa.moveToElement(kk).click().perform();
			
			Thread.sleep(2000);
			driver.findElement(By.xpath(
					"/html[1]/body[1]/div[2]/div[1]/div[2]/div[2]/div[2]/section[1]/div[1]/div[1]/div[2]/div[4]/div[1]/div[1]/ul[1]/li[3]/a[1]"))
					.click();
		
		System.out.println("Testcase 8 Done !!!");

	}

	void selectanyBike() {

		driver.findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[1]/div[2]/div[1]/section[2]/div[2]/div[1]/ul[1]/li[1]/div[1]/div[2]/div[1]/div[1]/div[1]/img[1]"))
				.click();
		
		System.out.println("Testcase 9 Done !!!");
	}
	
	

	public static void main(String[] args) throws InterruptedException {
	
		BikeWalaClass obj=new BikeWalaClass();
		
		obj.openPage();
		obj.checkUrl();
		Thread.sleep(2000);
		obj.selectCity();
		Thread.sleep(2000);
		obj.Tvs();
		Thread.sleep(2000);
		obj.topComparisons();
		Thread.sleep(2000);
		obj.review();
		Thread.sleep(2000);
		obj.clickHome();
		Thread.sleep(2000);
		obj.newLaunch();
		Thread.sleep(2000);
		obj.clickHome();
		Thread.sleep(2000);
		obj.BodyStyle();
		Thread.sleep(2000);
		obj.selectanyBike();
		
		
		
		
		
		

	}

}
